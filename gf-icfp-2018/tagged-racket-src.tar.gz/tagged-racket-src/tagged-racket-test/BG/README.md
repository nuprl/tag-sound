Summary
---

- `pass/` modules that compile & run successfully
- `fail/` modules that fail to type-check
- `error/` modules that type-check, but raise a run-time error


TODO
---

- re-use TR testing framework,
  and learn how it works
  instead of rolling yer own
