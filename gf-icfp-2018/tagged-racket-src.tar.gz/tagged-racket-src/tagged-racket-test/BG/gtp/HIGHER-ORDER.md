QUESTION: where do these use higher-order functions?

hmm, can I use defender to always wrap doms of function values?


determinance    | 
fsm             | never
gregor-worst    | looks like never, but I'm half-done
kcfa-worst
lnm-worst
mbta-worst
morsecode-worst
sieve-01
sieve-10
snake-worst
synth
tetris-worst
trie-vector
zombie-worst
zordoz-worst
