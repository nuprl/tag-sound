for BM in determinance fsm gregor-worst kcfa-worst lnm-worst mbta-worst morsecode-worst sieve-01 sieve-10 snake-worst synth tetris-worst trie-vector zombie-worst zordoz-worst; do
  echo ${BM};
  cd ${BM};
  raco make main.rkt && racket main.rkt;
  cd ..;
done
