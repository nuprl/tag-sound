base
====

Data files for the l-nm plotting benchmark.

- `data` files containing Racket vectors, representing experimental results
- `module-graphs` TiKZ pictures representing the inheritance hierarchy of a project
