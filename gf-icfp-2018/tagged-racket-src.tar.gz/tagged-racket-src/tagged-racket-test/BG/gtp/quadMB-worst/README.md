UTILS.rkt

problem in utils, cannot compile because of that idk wtf is wrong
