tagged racket is slower for this... hmm

- hash-ref inside `node-follow/k`
- `vector-ref` inside `label.rkt`

I guess these are called so often, it outweighs?
